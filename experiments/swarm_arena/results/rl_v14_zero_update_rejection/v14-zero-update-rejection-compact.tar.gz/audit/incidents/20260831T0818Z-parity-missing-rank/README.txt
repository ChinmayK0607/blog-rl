Operational launch failure before parity: torch.distributed env RANK unset. Scientific inputs and thresholds unchanged. Narrow recovery uses torch.distributed.run nproc_per_node=1.
