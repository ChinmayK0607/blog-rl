Watcher-only correction: exclude five preserved recovered preflight failure logs from active fault scan; all recovery and subsequent logs remain scanned.
